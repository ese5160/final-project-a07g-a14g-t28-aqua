/**************************************************************************/ 
/**
 * @file      CliThread.c
 * @brief     File for the CLI Thread handler. Uses FREERTOS + CLI
 ******************************************************************************/

/******************************************************************************
 * Includes
 ******************************************************************************/ 
#include "CliThread.h"
#include "semphr.h"
#include "circular_buffer.h"
#include "FreeRTOS.h"
#include "FreeRTOS_CLI.h"
#include "task.h"
#include "SerialConsole.h"
#include <string.h>
#include <stdio.h>

/******************************************************************************
 * Defines
 ******************************************************************************/ 
#define BUFFER_SIZE 512
#define FIRMWARE_VERSION "0.0.3"
#define MAX_INPUT_LENGTH_CLI 50
#define MAX_OUTPUT_LENGTH_CLI 128
#define ASCII_BACKSPACE 0x08
#define ASCII_DELETE 0x7F

/******************************************************************************
 * Variables
 ******************************************************************************/ 
static int8_t *const pcWelcomeMessage =
    "FreeRTOS CLI.\r\nType Help to view a list of registered commands.\r\n";

/******************************************************************************
 * CLI Command Definitions
 ******************************************************************************/ 
// Version Command Definition
static const CLI_Command_Definition_t xVersionCommand =
{
    "version",
    "version: Prints the firmware version\r\n",
    CLI_VersionCommand,
    0
};

// Tick Command Definition
static const CLI_Command_Definition_t xTickCommand =
{
    "tick",
    "tick: Prints the current tick count\r\n",
    CLI_TicksCommand,
    0
};

/******************************************************************************
 * CLI Command Implementations
 ******************************************************************************/ 
// Version Command Handler
BaseType_t CLI_VersionCommand(int8_t *pcWriteBuffer, size_t xWriteBufferLen, const int8_t *pcCommandString)
{
    snprintf((char*)pcWriteBuffer, xWriteBufferLen, "Firmware version: %s\r\n", FIRMWARE_VERSION);
    return pdFALSE; // Command handling completed
}

// Tick Command Handler
BaseType_t CLI_TicksCommand(int8_t *pcWriteBuffer, size_t xWriteBufferLen, const int8_t *pcCommandString)
{
    TickType_t tickCount = xTaskGetTickCount();
    snprintf((char*)pcWriteBuffer, xWriteBufferLen, "Tick Count: %lu\r\n", (unsigned long) tickCount);
    return pdFALSE; // Command handling completed
}

/******************************************************************************
 * FreeRTOS Read Function
 ******************************************************************************/ 
static void FreeRTOS_read(char *character)
{
    while (1)
    {
        if (SerialConsoleReadCharacter((uint8_t *)character) == 0)
        {
            // Check if it's Enter key (Either \r or \n)
            if (*character == '\n' || *character == '\r')
            {
                // Normalize Enter key to '\n' for consistency
                *character = '\n';
            }
            break; 
        }
        vTaskDelay(1); 
    }
}

/******************************************************************************
 * CLI Task Function
 ******************************************************************************/ 
void vCommandConsoleTask(void *pvParameters)
{
    
    uint8_t cRxedChar[2], cInputIndex = 0;
    BaseType_t xMoreDataToFollow;
    static char pcOutputString[MAX_OUTPUT_LENGTH_CLI], pcInputString[MAX_INPUT_LENGTH_CLI];
    char rxChar;

    // Register version command
    if (FreeRTOS_CLIRegisterCommand(&xVersionCommand) == pdTRUE)
    {
        SerialConsoleWriteString("Version command registered successfully.\r\n");
    }

    // Register tick command
    if (FreeRTOS_CLIRegisterCommand(&xTickCommand) == pdTRUE)
    {
        SerialConsoleWriteString("Tick command registered successfully.\r\n");
    }

    SerialConsoleWriteString(pcWelcomeMessage);

    for (;;)
    {
        FreeRTOS_read(&rxChar);

        // Check for Enter Key (Compatible with both /r and /n or either one)
        if (rxChar == '\n' || rxChar == '\r' || rxChar == 0x0D || rxChar == 0x0A)
        {
            SerialConsoleWriteString("\r\n");
            pcInputString[cInputIndex] = '\0';

            do
            {
                xMoreDataToFollow = FreeRTOS_CLIProcessCommand(pcInputString, pcOutputString, MAX_OUTPUT_LENGTH_CLI);
                SerialConsoleWriteString(pcOutputString);

            } while (xMoreDataToFollow != pdFALSE);

            cInputIndex = 0;
            memset(pcInputString, 0, MAX_INPUT_LENGTH_CLI);
        }
        // Handle Backspace/Delete Key
        else if (rxChar == ASCII_BACKSPACE || rxChar == ASCII_DELETE)
        {
            if (cInputIndex > 0)
            {
                cInputIndex--;
                pcInputString[cInputIndex] = '\0';
                SerialConsoleWriteString("\b \b");
            }
        }
        // Normal Character Input
        else
        {
            if (cInputIndex < MAX_INPUT_LENGTH_CLI - 1)
            {
                pcInputString[cInputIndex++] = rxChar;
            }

            cRxedChar[0] = rxChar;
            cRxedChar[1] = '\0';
            SerialConsoleWriteString((char*)cRxedChar);
        }
    }
}
