#include "Debug.h"  // ȷ��·����ȷ
#include "SerialConsole.h"

static eDebugLogLevels currentDebugLevel = LOG_INFO_LVL;  // Default log level

/**
 * @brief Gets the current debug log level.
 * @return The current debug level.
 */
eDebugLogLevels getLogLevel(void)
{
    return currentDebugLevel;
}

/**
 * @brief Sets the debug log level.
 * @param debugLevel The debug level to set.
 */
void setLogLevel(eDebugLogLevels debugLevel)
{
    if (debugLevel < N_DEBUG_LEVELS) {
        currentDebugLevel = debugLevel;
    }
}

/**
 * @brief Logs a message at the specified debug level.
 */
void LogMessage(eDebugLogLevels level, const char *format, ...)
{
    if (level >= currentDebugLevel)
    {
        char buffer[256];
        va_list args;

        va_start(args, format);
        vsnprintf(buffer, sizeof(buffer), format, args);
        va_end(args);

        SerialConsoleWriteString(buffer);
    }
}
