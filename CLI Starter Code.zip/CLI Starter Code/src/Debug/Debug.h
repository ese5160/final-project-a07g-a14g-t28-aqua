#ifndef DEBUG_H
#define DEBUG_H

#include <stdio.h>
#include <stdarg.h>

/******************************************************************************
 * Enumerations
 ******************************************************************************/
typedef enum {  // Make sure it's typedef, not just 'enum'
    LOG_INFO_LVL    = 0,
    LOG_DEBUG_LVL   = 1,
    LOG_WARNING_LVL = 2,
    LOG_ERROR_LVL   = 3,
    LOG_FATAL_LVL   = 4,
    LOG_OFF_LVL     = 5,
    N_DEBUG_LEVELS  = 6
} eDebugLogLevels;

/******************************************************************************
 * Function Declarations
 ******************************************************************************/
void LogMessage(eDebugLogLevels level, const char *format, ...);
void setLogLevel(eDebugLogLevels debugLevel);
eDebugLogLevels getLogLevel(void);

#endif // DEBUG_H
